﻿# The Protocol â€” copia estÃ¡tica

Esta carpeta contiene una captura estÃ¡tica de las pÃ¡ginas pÃºblicas de The Protocol.

## Limitaciones

GitHub Pages sirve HTML, CSS, JavaScript e imÃ¡genes, pero no ejecuta PHP ni WordPress. Por eso esta copia conserva la apariencia y navegaciÃ³n pÃºblica, pero no puede procesar formularios, login, WooCommerce, LearnDash, usuarios ni contenido dinÃ¡mico.

La copia integral restaurable estÃ¡ documentada por separado en `the-protocol-backup-documentacion` y debe mantenerse fuera de este sitio pÃºblico.
